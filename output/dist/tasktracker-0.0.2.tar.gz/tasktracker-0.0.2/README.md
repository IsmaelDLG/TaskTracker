# Task Tracker

Task Tracker es una aplicación para mantener un registro de las tareas realizadas. Con ella podrás saber a que hora cuanto tiempo dedicas a tus tareas. Podrás organizarlas con etiquetas customizables y podrás exportar tus datos y hacer copias de seguridad.

- [Task Tracker](#task-tracker)
  - [Documentación](#documentación)
  - [Quickstart](#quickstart)
  - [ToDo List](#todo-list)

## Documentación

Encontrarás la documentación del proyecto [aquí](./docs/1-Introduction.md)

## Quickstart

Work in progres.

## ToDo List

| **Description**                       | Status      |
| ------------------------------------- | ----------- |
| Make it a package                     | **DONE**    |
| Git repository + GitHub               | **DONE**    |
| Create logging                        | NOT STARTED |
| Document the code (python docstrings) | NOT STARTED |
| Make tests                            | NOT STARTED |
| Create a cross-platform Makefile      | NOT STARTED |
| Make the app configurable             | NOT STARTED |
| Make a "roadmap" for this project     | NOT STARTED |
